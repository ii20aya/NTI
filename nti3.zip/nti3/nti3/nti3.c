/*
 * nti3.c
 *
 * Created: 9/3/2024 
 *  Author: aya abdulaziz
 */ 


#include <avr/io.h>
#define F_CPU 8000000UL
#include "MCAL/ADC/ADC_interface.h"
#include "MCAL/DIO/DIO_interface.h"
#include "HAL/CLCD2/CLCD_INTERFACE.h"
#include "COMM/USART_interface.h"
#include "HAL/Keypad2/Keypad2_interface.h"
#include <stdlib.h>
#include <util/delay.h>


int main(void)
{
  CLCD_init();
  Kypad_init();
  ADC_Enable();
  ADC_voidInit();
  
  USART_voidINIT();
  
  DIO_enumSetPinDirection(DIO_PIN6 , DIO_PORTD ,1);  //led1 room 1 --> output
  DIO_enumSetPinDirection(DIO_PIN7 , DIO_PORTD ,1);  //motor1 room 1 --> output
  DIO_enumSetPinDirection(DIO_PIN2 , DIO_PORTD ,1);  //led2 room 1 --> output
  
  DIO_enumSetPinDirection(DIO_PIN3 , DIO_PORTD ,1);  //led1 room 2 --> output
  DIO_enumSetPinDirection(DIO_PIN4 , DIO_PORTD ,1);  //motor1 room 2 --> output
  DIO_enumSetPinDirection(DIO_PIN5 , DIO_PORTD ,1);  //led2 room 2 --> output
  
  DIO_enumSetPinDirection(DIO_PIN0 , DIO_PORTA ,0);  //LM35 --> input
  DIO_enumSetPinDirection(DIO_PIN1 , DIO_PORTA ,1);  //buzzer --> output
  DIO_enumSetPinDirection(DIO_PIN2 , DIO_PORTA ,1);  //led alert system --> output
  
  U8 arr_idcheck[2][3]={{'1','2','3'}
                     ,{'4','5','6'}}; //ID for users --> 123 , 456
               
  U8 arr_passcheck[2][3]={{'7','7','7'}
               ,{'8','8','8'}}; //pass for users --> 777 , 888
            
  U8 id[3], pass[3] ,room=0 ,r1=0 ,r2=0 , alert=0;
  int i = 0 , digit=0 , count = 0 , user = 0 ;
  U16 t_value;
  char adc_str[5];


 
   while(1)
    {
		 USART_VoidSendString("welcome . . . ");
		 _delay_ms(800);
		 USART_voidTRANSMITR('\r'); // new line in terminal
		 USART_voidTRANSMITR('\n');
		
   t_value= ADC_u16GetChannalResult(ADC_CHANNAL_0);
   t_value=(t_value*5000.0)/10230;
   if( ((int)t_value ) > 30)
    {
      CLCD_GoTo(1,1);
      CLCD_SendString("Alert . . . !!");
      _delay_ms(300);
	  CLCD_GoTo(2,1);
	  t_value= ADC_u16GetChannalResult(ADC_CHANNAL_0);
	  t_value=(t_value*5000.0)/10230;
	  itoa(t_value, adc_str, 10);
	  CLCD_SendString(adc_str);
      CLCD_WriteChar(0XDF);
      CLCD_WriteChar(0X43);
       DIO_enumSetPinValue(DIO_PIN1 , DIO_PORTA ,1);  //buzzer on
       DIO_enumSetPinValue(DIO_PIN2 , DIO_PORTA ,1);
       _delay_ms(1000);
    
    
    do
    {
      alert = Kypad_GetKey();
    }while (alert == 'f');
    
    if(alert=='c'){ //control on alert
    
    DIO_enumSetPinValue(DIO_PIN1 , DIO_PORTA ,0);  //buzzer off
    DIO_enumSetPinValue(DIO_PIN2 , DIO_PORTA ,0);
    CLCD_CLR();
    }      
      
    }
       USART_VoidSendString("Enter your ID: ");
    for ( i = 0; i < 3; i++) //get ID which compose of 3 digit
    {
       do
       {
         id[i] = Kypad_GetKey();
       }while (id[i] == 'f');
     USART_voidTRANSMITR(id[i]);
     
    }
    
     for (user = 0; user <=1 ; user++)
     {
       for ( i = 0; i < 3; i++)
       {
          if ((id[i] == arr_idcheck[user][i]) ) //ID is correct
         {
           ++digit;
         }
       }
       if (digit==3)
       {
         break;
       }
    }
      ///////
     if (digit==3)// action will be take -->id correct
     {
        USART_voidTRANSMITR('\r'); // new line in terminal
        USART_voidTRANSMITR('\n'); 
       USART_VoidSendString("Enter your Pass: ");
       for ( i = 0; i < 3; i++) //get pass from keypad 
       {
         do
         {
           pass[i] = Kypad_GetKey();
         }while (pass[i] == 'f');
         USART_VoidSendString("*");
        
       }
       
       //check pass for selected user
        for ( i = 0; i < 3; i++)
        {
          if ((pass[i] == arr_passcheck[user][i]) ) //pass for selected user is correct
          {
            continue;
          
         }
         else{ //pass for this user is incorrect
          
            //chnace to re-enter pass --> 2 times
            CLCD_GoTo(1,1);
            CLCD_SendString("pass incorrect");
            _delay_ms(300);
            CLCD_GoTo(2,1);
            CLCD_SendString("left trial");
            _delay_ms(200);
            CLCD_GoTo(2,12);
            CLCD_WritNum(1);
            _delay_ms(450);
            CLCD_CLR();
            
             USART_voidTRANSMITR('\r'); // new line in terminal
             USART_voidTRANSMITR('\n');
			 USART_VoidSendString("RE-Enter Pass: ");
			 for ( i = 0; i < 3; i++) //get pass from keypad
			 {
				 do
				 {
					 pass[i] = Kypad_GetKey();
				 }while (pass[i] == 'f');
				 USART_VoidSendString("*");
				 
			 }
			 //re-check on pass
			 for ( i = 0; i < 3; i++)
			 {
				 if ((pass[i] == arr_passcheck[user][i]) ) //pass for selected user is correct
				 {
					 continue;
					 
				 }
				 else{
					 break; //rom re-ckeck loop
				 }
				 
				
			 }
			 if(i!=3){ //pass incorrect for the secomd time
			 CLCD_GoTo(1,2);
			 CLCD_SendString("system hacking");
			 _delay_ms(200);
			 CLCD_CLR();
			 CLCD_GoTo(1,2);
			 CLCD_SendString("system hacking");
			 _delay_ms(250);
			 CLCD_CLR();
			 break;
			 }
			 else if(i==3){
			  break;
			  i==3;
			  }
		 }
	 }
	 if(i==3){ //last loop is end successfully --> pass is correct
	 USART_voidTRANSMITR('\r'); // new line in terminal
	 USART_voidTRANSMITR('\n');
	 USART_VoidSendString("ROOM 1 ?  ");
	 _delay_ms(300);
	 USART_VoidSendString(" ROOM 2 ?  ");
	 do //wait user to choose room?
	 {
		 room=Kypad_GetKey();
		 
	 } while(room=='f');
	 if(room=='1'){
		 CLCD_GoTo(1,2);
		 CLCD_SendString("IN ROOM 1");
		 _delay_ms(1300);
		 USART_voidTRANSMITR('\r'); // new line in terminal
		 USART_voidTRANSMITR('\n');
		 USART_VoidSendString("1-LED1  ");
		 USART_VoidSendString("2-LED2  ");
		 USART_VoidSendString("3-FAN");
		 
		 do
		 {
			 r1 = Kypad_GetKey();
		 }while (r1== 'f');
		 if(r1=='1'){
			 DIO_enumSetPinValue(DIO_PIN6 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("LED1 ON");}
		 else if(r1=='2'){
			 DIO_enumSetPinValue(DIO_PIN2 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("LED2 ON");}
		 else if(r1=='3'){
			 DIO_enumSetPinValue(DIO_PIN7 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("FAN ON");}
		 
		 _delay_ms(2000);
		 DIO_enumSetPinValue(DIO_PIN6 , DIO_PORTD ,0);
		 DIO_enumSetPinValue(DIO_PIN7 , DIO_PORTD ,0);
		 DIO_enumSetPinValue(DIO_PIN2 , DIO_PORTD ,0);
		 CLCD_CLR();
	 }
	 else if(room=='2'){
		 CLCD_GoTo(1,2);
		 CLCD_SendString("IN ROOM 2");
		 _delay_ms(1300);
		 USART_voidTRANSMITR('\r'); // new line in terminal
		 USART_voidTRANSMITR('\n');
		 USART_VoidSendString("1-LED1  ");
		 USART_VoidSendString("2-LED2  ");
		 USART_VoidSendString("3-FAN");
		 
		 
		 do
		 {
			 r2 = Kypad_GetKey();
		 }while (r2== 'f');
		 if(r2=='1'){
			 DIO_enumSetPinValue(DIO_PIN3 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("LED1 ON");}
		 else if(r2=='2'){
			 DIO_enumSetPinValue(DIO_PIN5 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("LED2 ON");}
		 else if(r2=='3'){
			 DIO_enumSetPinValue(DIO_PIN4 , DIO_PORTD ,1);
			 CLCD_GoTo(2,2);
		 CLCD_SendString("FAN ON");}
		 
		 _delay_ms(2000);
		 DIO_enumSetPinValue(DIO_PIN4 , DIO_PORTD ,0);
		 DIO_enumSetPinValue(DIO_PIN5 , DIO_PORTD ,0);
		 DIO_enumSetPinValue(DIO_PIN3 , DIO_PORTD ,0);
		 CLCD_CLR();
	 }
	 
 }
 
 
    }
     
      if (digit!=3) // action will be take -->id incorrect
      {
        CLCD_GoTo(1,1);
      CLCD_SendString("ID incorrect");
      _delay_ms(500);
       CLCD_GoTo(2,1);
       CLCD_SendString("system close");
       _delay_ms(550);
      CLCD_CLR();
      }
      digit=0;
      USART_voidTRANSMITR('\r'); // new line in terminal
      USART_voidTRANSMITR('\n');
     
     
    
    }//end while
    
    }