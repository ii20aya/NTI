#include"../../LIB/STD_TYPES.h"
#include"../../LIB/BIT_MATH.h"
#include"../../MCAL/DIO/DIO_interface.h"
#include"LED_interface.h"
U8 state=1;
void LED_VoidInit(LED_State copy_structLedConfig){
	DIO_enumSetPinDirection(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_OUTPUT);
}
void LED_VoidON(LED_State copy_structLedConfig){
	state=1;
	if(copy_structLedConfig.State==LED_ActiveHigh){
		DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_HIGH);
	}else if(copy_structLedConfig.State==LED_ActiveLow){
		DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_LOW);

	}
}
void LED_VoidOFF(LED_State copy_structLedConfig){
	state=0;
	if(copy_structLedConfig.State==LED_ActiveHigh){
		DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_LOW);
	}else if(copy_structLedConfig.State==LED_ActiveLow){
		DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_HIGH);

	}
}
void LED_VoidTOG(LED_State copy_structLedConfig){
	if(copy_structLedConfig.State==LED_ActiveHigh){
		if(state==1){
			DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_LOW);
		}else if(state==0){
			DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_HIGH);
		}
	}else if(copy_structLedConfig.State==LED_ActiveLow){
		if(state==1){
			DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_HIGH);
		}else if(state==0){
			DIO_enumSetPinValue(copy_structLedConfig.pin,copy_structLedConfig.port,DIO_LOW);
		}
	}
}
