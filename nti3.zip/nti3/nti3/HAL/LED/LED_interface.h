#ifndef LED_INTERFACE_H_
#define LED_INTERFACE_H_

#define LED_ActiveHigh  1
#define LED_ActiveLow   0

typedef struct{
	U8 port;
	U8 pin;
	U8 State;

}LED_State;

void LED_VoidInit(LED_State copy_structLedConfig);
void LED_VoidON(LED_State copy_structLedConfig);
void LED_VoidOFF(LED_State copy_structLedConfig);
void LED_VoidTOG(LED_State copy_structLedConfig);

#endif
