/*
 * SSD_config.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SSD_SSD_CONFIG_H_
#define HAL_SSD_SSD_CONFIG_H_
#include"../../MCAL/DIO/DIO_interface.h"

#define SSD_PORTNAME DIO_PORTD

#endif /* HAL_SSD_SSD_CONFIG_H_ */
