/*
 * SSD_interface.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SSD_SSD_INTERFACE_H_
#define HAL_SSD_SSD_INTERFACE_H_

#define SSD_COMMON_CATHODE 0
#define SSD_COMMON_ANODE   1
#define SSD_Enable_Dot     2
#define SSD_Disable_Dot    3

typedef struct{
	U8 ssd_type;
	U8 ssd_port;
	U8 Enable_pin;
	U8 Enable_port;
    U8 DOT_State;
}SSD_STATE;

void SSD_voidInit(void);
void SSD_voidSedndNumber(SSD_STATE Copy_structSSDConfig,U8 Copy_u8Number);
void SSD_voidEnable(SSD_STATE Copy_structSSDConfig);
void SSD_voidDisable(SSD_STATE Copy_structSSDConfig);


#endif /* HAL_SSD_SSD_INTERFACE_H_ */
