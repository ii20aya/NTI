/*
 * SSD_program.c
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */
#include"../../LIB/STD_TYPES.h"
#include"../../LIB/BIT_MATH.h"
#include"../../MCAL/DIO/DIO_interface.h"
#include"SSD_interface.h"
#include"SSD_config.h"
U8 SSD_arr[10]={0b0111111,0b0000110,0X5B,0X4F,0X66,0X6D,0X7D,0X7,0X7F,0X6F};
void SSD_voidInit(void){
	DIO_enumSetPortDirection(SSD_PORTNAME,255);
}
void SSD_voidSedndNumber(SSD_STATE Copy_structSSDConfig,U8 Copy_u8Number){
	if(Copy_structSSDConfig.ssd_type==SSD_COMMON_ANODE){
		DIO_enumSetPortValue(Copy_structSSDConfig.ssd_port,~(SSD_arr[Copy_u8Number]));
		if( Copy_structSSDConfig.DOT_State==SSD_Enable_Dot){
			DIO_enumSetPinValue(DIO_PIN7, Copy_structSSDConfig.ssd_port,DIO_LOW);
		}else if(Copy_structSSDConfig.DOT_State==SSD_Disable_Dot){
			DIO_enumSetPinValue(DIO_PIN7, Copy_structSSDConfig.ssd_port,DIO_HIGH);
		}
	}else if(Copy_structSSDConfig.ssd_type==SSD_COMMON_CATHODE){
		DIO_enumSetPortValue(Copy_structSSDConfig.ssd_port,(SSD_arr[Copy_u8Number]));
		if( Copy_structSSDConfig.DOT_State==SSD_Enable_Dot){
			DIO_enumSetPinValue(DIO_PIN7, Copy_structSSDConfig.ssd_port,DIO_HIGH);
		}else if(Copy_structSSDConfig.DOT_State==SSD_Disable_Dot){
			DIO_enumSetPinValue(DIO_PIN7, Copy_structSSDConfig.ssd_port,DIO_LOW);
		}
	}
}
void SSD_voidEnable(SSD_STATE Copy_structSSDConfig){
	if(Copy_structSSDConfig.ssd_type==SSD_COMMON_ANODE){
		DIO_enumSetPinDirection(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_OUTPUT);
		DIO_enumSetPinValue(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_HIGH);
	}else if(Copy_structSSDConfig.ssd_type==SSD_COMMON_CATHODE){
		DIO_enumSetPinDirection(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_OUTPUT);
		DIO_enumSetPinValue(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_LOW);
	}
}
void SSD_voidDisable(SSD_STATE Copy_structSSDConfig){
	if(Copy_structSSDConfig.ssd_type==SSD_COMMON_ANODE){
		DIO_enumSetPinDirection(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_OUTPUT);
		DIO_enumSetPinValue(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_LOW);
	}else if(Copy_structSSDConfig.ssd_type==SSD_COMMON_CATHODE){
		DIO_enumSetPinDirection(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_OUTPUT);
		DIO_enumSetPinValue(Copy_structSSDConfig.Enable_pin,Copy_structSSDConfig.Enable_port,DIO_HIGH);
	}
}
