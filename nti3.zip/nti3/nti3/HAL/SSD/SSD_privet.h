/*
 * SSD_privet.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SSD_SSD_PRIVET_H_
#define HAL_SSD_SSD_PRIVET_H_



#endif /* HAL_SSD_SSD_PRIVET_H_ */
