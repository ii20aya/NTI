/*
 * interface.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SW_SW_INTERFACE_H_
#define HAL_SW_SW_INTERFACE_H_

#define SW_PullUp   0
#define SW_Flloting 1

typedef struct{
	U8 Port;
	U8 Pin;
	U8 State;
}SW_State;

void SW_voidInit(SW_State Copy_StructConfig);
U8   SW_u8GetPressed(SW_State Copy_StructConfig);

#endif /* HAL_SW_SW_INTERFACE_H_ */
