/*
 * privet.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SW_SW_PRIVET_H_
#define HAL_SW_SW_PRIVET_H_



#endif /* HAL_SW_SW_PRIVET_H_ */
