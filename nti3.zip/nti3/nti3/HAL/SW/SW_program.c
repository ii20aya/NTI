/*
 * program.c

 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */
#include"../../LIB/STD_TYPES.h"
#include"../../LIB/BIT_MATH.h"
#include"../../MCAL/DIO/DIO_interface.h"
#include"SW_interface.h"
void SW_voidInit(SW_State Copy_StructConfig){
	DIO_enumSetPinDirection(Copy_StructConfig.Pin,Copy_StructConfig.Port,DIO_INPUT);
	if(Copy_StructConfig.State==SW_PullUp){
		DIO_enumSetPinValue(Copy_StructConfig.Pin,Copy_StructConfig.Port,DIO_HIGH);
	}
}
U8   SW_u8GetPressed(SW_State Copy_StructConfig){
	U8 LOC_u8GetPressed;
	LOC_u8GetPressed=0;
	DIO_enumGetPinValue(Copy_StructConfig.Port,Copy_StructConfig.Pin,&LOC_u8GetPressed);
	return LOC_u8GetPressed;
}
