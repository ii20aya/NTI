/*
 * config.h
 *
 *  Created on: Feb 23, 2022
 *      Author: INTEL
 */

#ifndef HAL_SW_SW_CONFIG_H_
#define HAL_SW_SW_CONFIG_H_



#endif /* HAL_SW_SW_CONFIG_H_ */
