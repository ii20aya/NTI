/*
 * Keypad_privet.h
 *
 *  Created on: Mar 10, 2022
 *      Author: INTEL
 */

#ifndef HAL_KEYPAD2_KEYPAD2_PRIVET_H_
#define HAL_KEYPAD2_KEYPAD2_PRIVET_H_
#include"Keypad2_config.h"
U8 KeyPad_u8RW[4]={Keypad_RW0,Keypad_RW1,Keypad_RW2,Keypad_RW3};
U8 KeyPad_u8COL[4]={Keypad_col0,Keypad_col1,Keypad_col2,Keypad_col3};

#endif /* HAL_KEYPAD2_KEYPAD2_PRIVET_H_ */
