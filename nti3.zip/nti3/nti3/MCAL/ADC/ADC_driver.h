/*
 * ADC_driver.h
 *
 * Created: 3/3/2018 5:00:21 PM
 *  Author: Mohamed Zaghlol
 */ 


#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_

void ADC_vinit(void);
 unsigned short ADC_u16Read(void);



#endif /* ADC_DRIVER_H_ */