/*
 * GIE_interface.h
 *
 *  Created on: Mar 20, 2022
 *      Author: INTEL
 */

#ifndef MCAL_GIE_GIE_INTERFACE_H_
#define MCAL_GIE_GIE_INTERFACE_H_

void GIE_voidEnable(void);
void GIE_voidDisable(void);



#endif /* MCAL_GIE_GIE_INTERFACE_H_ */
