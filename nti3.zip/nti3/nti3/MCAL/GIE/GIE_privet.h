/*
 * GIE_privet.h
 *
 *  Created on: Mar 20, 2022
 *      Author: INTEL
 */

#ifndef MCAL_GIE_GIE_PRIVET_H_
#define MCAL_GIE_GIE_PRIVET_H_

#define SREG  *((volatile U8*)0X5F)
#define GIE_u8_I_BIT 7

#endif /* MCAL_GIE_GIE_PRIVET_H_ */
