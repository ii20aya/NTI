/*
 * GIE_program.c
 *
 *  Created on: Mar 20, 2022
 *      Author: INTEL
 */
#include"../../LIB/STD_TYPES.h"
#include"../../LIB/BIT_MATH.h"
#include"GIE_privet.h"
#include"GIE_interface.h"
void GIE_voidEnable(void){
	SET_BIT(SREG,GIE_u8_I_BIT);
}
void GIE_voidDisable(void){
	CLR_BIT(SREG,GIE_u8_I_BIT);
}

